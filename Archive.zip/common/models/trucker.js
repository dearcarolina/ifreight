module.exports = function(Trucker) {

};
